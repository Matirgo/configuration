import asyncio

from botocore.retries.standard import (
    _SERVICE_MAX_ATTEMPTS,
    DEFAULT_MAX_ATTEMPTS,
    NEW_RETRIES_ENABLED,
    ExponentialBackoff,
    MaxAttemptsChecker,
    MaxAttemptsSeeder,
    ModeledRetryableChecker,
    OrRetryChecker,
    RetryEventAdapter,
    RetryHandler,
    RetryPolicy,
    RetryQuotaChecker,
    StandardRetryConditions,
    ThrottledRetryableChecker,
    ThrottlingErrorDetector,
    TransientRetryableChecker,
    logger,
    quota,
    special,
)

from .._helpers import async_any, resolve_awaitable
from ..httpxsession import HttpxSession
from .special import AioRetryDDBChecksumError


def register_retry_handler(client, max_attempts=None):
    service_id = client.meta.service_model.service_id
    service_event_name = service_id.hyphenize()
    retry_event_adapter = RetryEventAdapter()
    retry_handler_cls = (
        AnyioRetryHandler
        if isinstance(client._endpoint.http_session, HttpxSession)
        else AioRetryHandler
    )

    if NEW_RETRIES_ENABLED:
        if (
            max_attempts is None
            and service_event_name in _SERVICE_MAX_ATTEMPTS
        ):
            max_attempts = _SERVICE_MAX_ATTEMPTS[service_event_name]
        elif max_attempts is None:
            max_attempts = DEFAULT_MAX_ATTEMPTS
        # The ``max`` token of the ``amz-sdk-request`` header is otherwise
        # only populated once a retry is attempted, so it's missing from
        # the initial attempt.  Seeding it here ensures that it's present
        # on every attempt. This handler runs before ``add_retry_headers``
        # because the emitter invokes more specific events first, and
        # ``add_retry_headers`` is registered on the generic
        # ``request-created``.
        client.meta.events.register(
            f'request-created.{service_event_name}',
            MaxAttemptsSeeder(max_attempts).seed_max_attempts,
            unique_id=f'seed-max-attempts-{service_event_name}',
        )
        throttling_detector = ThrottlingErrorDetector(retry_event_adapter)
        retry_quota = RetryQuotaChecker(
            quota.RetryQuota(), throttling_detector
        )
        handler = retry_handler_cls(
            retry_policy=AioRetryPolicy(
                retry_checker=AioStandardRetryConditions(
                    max_attempts=max_attempts
                ),
                retry_backoff=ExponentialBackoff(
                    service_name=service_event_name,
                    throttling_detector=throttling_detector,
                ),
            ),
            retry_event_adapter=retry_event_adapter,
            retry_quota=retry_quota,
            service_name=service_event_name,
        )
    else:
        retry_quota = RetryQuotaChecker(quota.RetryQuota())
        handler = retry_handler_cls(
            retry_policy=AioRetryPolicy(
                retry_checker=AioStandardRetryConditions(
                    max_attempts=max_attempts or DEFAULT_MAX_ATTEMPTS
                ),
                retry_backoff=ExponentialBackoff(),
            ),
            retry_event_adapter=retry_event_adapter,
            retry_quota=retry_quota,
        )

    client.meta.events.register(
        f'after-call.{service_event_name}', retry_quota.release_retry_quota
    )
    unique_id = f'retry-config-{service_event_name}'
    client.meta.events.register(
        f'needs-retry.{service_event_name}',
        handler.needs_retry,
        unique_id=unique_id,
    )
    return handler


class AioRetryHandler(RetryHandler):
    def __init__(self, *args, sleep=asyncio.sleep, **kwargs):
        super().__init__(*args, sleep=sleep, **kwargs)

    async def needs_retry(self, **kwargs):
        """Connect as a handler to the needs-retry event."""
        retry_delay = None
        context = self._retry_event_adapter.create_retry_context(**kwargs)
        if await self._retry_policy.should_retry(context):
            # Before we can retry we need to ensure we have sufficient
            # capacity in our retry quota.
            if self._retry_quota.acquire_retry_quota(context):
                retry_delay = self._retry_policy.compute_retry_delay(context)
                logger.debug(
                    "Retry needed, retrying request after delay of: %s",
                    retry_delay,
                )
            else:
                if NEW_RETRIES_ENABLED:
                    if self._is_long_polling_operation(context):
                        polling_delay = self._retry_policy.compute_retry_delay(
                            context
                        )
                        await self._sleep(polling_delay)
                        logger.debug(
                            "Retry needed but retry quota reached, "
                            "not retrying request."
                        )
                        self._retry_event_adapter.adapt_retry_response_from_context(
                            context
                        )
                        # Return False (non-None) to prevent any later needs-retry
                        # handler from returning a delay that would cause
                        # _needs_retry in endpoint.py to sleep again.
                        return False
                logger.debug(
                    "Retry needed but retry quota reached, "
                    "not retrying request."
                )
        else:
            logger.debug("Not retrying request.")
        self._retry_event_adapter.adapt_retry_response_from_context(context)
        return retry_delay


class AnyioRetryHandler(AioRetryHandler):
    def __init__(self, *args, **kwargs):
        import anyio

        super().__init__(*args, sleep=anyio.sleep, **kwargs)


class AioRetryPolicy(RetryPolicy):
    async def should_retry(self, context):
        return await resolve_awaitable(
            self._retry_checker.is_retryable(context)
        )


class AioStandardRetryConditions(StandardRetryConditions):
    def __init__(self, max_attempts=DEFAULT_MAX_ATTEMPTS):  # noqa: E501, lgtm [py/missing-call-to-init]
        # Note: This class is for convenience so you can have the
        # standard retry condition in a single class.
        self._max_attempts_checker = MaxAttemptsChecker(max_attempts)
        self._additional_checkers = AioOrRetryChecker(
            [
                TransientRetryableChecker(),
                ThrottledRetryableChecker(),
                ModeledRetryableChecker(),
                AioOrRetryChecker(
                    [
                        special.RetryIDPCommunicationError(),
                        AioRetryDDBChecksumError(),
                    ]
                ),
            ]
        )

    async def is_retryable(self, context):
        return self._max_attempts_checker.is_retryable(
            context
        ) and await resolve_awaitable(
            self._additional_checkers.is_retryable(context)
        )


class AioOrRetryChecker(OrRetryChecker):
    async def is_retryable(self, context):
        return await async_any(
            checker.is_retryable(context) for checker in self._checkers
        )
