# History of changes

## Version 6.1.7 (2026-08-27)

### New features

* Increase threshold to warn users when an array or dataframe is too big to be
  viewed in the Variable Explorer. The new limit is 50 million elements.

### Important fixes

* Fix formatting and linting with Ruff.
* Fix warning to tell users that an array or dataframe is too big to be handled
  by the Variable Explorer.
* Fix syntax highlighting of non-Python files in the Editor.
* Fix crash at startup when the in-app appeal page can't be read from disk.
* Make right-clicking on Files and Projects select the file where it's done.
