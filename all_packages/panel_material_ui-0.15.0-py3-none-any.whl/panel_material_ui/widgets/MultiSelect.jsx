import InputLabel from "@mui/material/InputLabel"
import FormControl from "@mui/material/FormControl"
import FormHelperText from "@mui/material/FormHelperText"
import Select from "@mui/material/Select"
import OutlinedInput from "@mui/material/OutlinedInput"
import FilledInput from "@mui/material/FilledInput"
import Input from "@mui/material/Input"
import {DESCRIPTION_LABEL_SPACER, render_description} from "./description"
import {MUI_SIZE, denseSx, render_icon_text, render_icon_text_as_string} from "./utils"

export function render({model, view, el}) {
  const [color] = model.useState("color")
  const [disabled] = model.useState("disabled")
  const [error_state] = model.useState("error_state")
  const [helper_text] = model.useState("helper_text")
  const [label] = model.useState("label")
  const [max_items] = model.useState("max_items")
  const [options] = model.useState("options")
  const [size] = model.useState("size")
  const [visual_size] = model.useState("visual_size")
  const [value, setValue] = model.useState("value")
  const [variant] = model.useState("variant")
  const [sx] = model.useState("sx")

  const ref = React.useRef(null)
  React.useEffect(() => {
    const focus_cb = (msg) => ref.current?.focus()
    model.on("msg:custom", focus_cb)
    return () => model.off("msg:custom", focus_cb)
  }, [])

  const handleChange = (event) => {
    const {options} = event.target
    const newSelections = []
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        newSelections.push(options[i].value)
      }
    }
    if (!max_items) {
      setValue(newSelections)
      return
    }

    const added = newSelections.find(item => !value.includes(item));
    if (added) {
      const newValue = [...value, added];
      if (max_items && newValue.length > max_items) {
        newValue.shift();
      }
      setValue(newValue);
    } else {
      setValue(newSelections);
    }
  }

  // The floating label/notch legend is a string-only slot, so tokens are stripped
  const label_text = render_icon_text_as_string(label)
  const label_spacer = label_text ? `${label_text}${model.description ? DESCRIPTION_LABEL_SPACER : ""}` : null

  const inputId = `select-multiple-native-${model.id}`

  const inputProps = {
    inputRef: ref,
    id: inputId,
    label: label_spacer
  };

  return (
    <FormControl disabled={disabled} error={error_state} fullWidth variant={variant}>
      {label &&
        <InputLabel id={`select-multiple-label-${model.id}`} shrink htmlFor={inputId}>
          {render_icon_text(label)}
          {model.description ? render_description({model, el, view}) : null}
        </InputLabel>
      }
      <Select
        color={color}
        input={
          variant === "outlined" ?
            <OutlinedInput {...inputProps}/> :
            variant === "filled" ?
              <FilledInput {...inputProps}/> :
              <Input {...inputProps}/>
        }
        inputProps={{size: size || undefined}}
        labelId={`select-multiple-label-${model.id}`}
        multiple
        size={MUI_SIZE(visual_size)}
        native
        onChange={handleChange}
        sx={denseSx(visual_size, sx)}
        value={value}
      >
        {options.map((name) => (
          <option
            key={name}
            value={name}
          >
            {render_icon_text_as_string(name)}
          </option>
        ))}
      </Select>
      {helper_text && <FormHelperText>{render_icon_text(helper_text)}</FormHelperText>}
    </FormControl>
  );
}
