from .utility cimport pair
