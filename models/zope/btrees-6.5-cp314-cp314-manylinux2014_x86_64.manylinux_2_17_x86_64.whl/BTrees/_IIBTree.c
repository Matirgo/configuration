/*############################################################################
#
# Copyright (c) 2004 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#
############################################################################*/

#define MASTER_ID "$Id$\n"

/* IIBTree - int key, int value BTree

   Implements a collection using int type keys
   and int type values
*/

/* Setup template macros */

#define PERSISTENT

#define MOD_NAME_PREFIX "II"

/* ``byValue`` only exists for the ``II`` and ``LL`` families, the two
   modules reachable as ``family32.II`` and ``family64.II``.  See
   https://github.com/zopefoundation/BTrees/issues/226
*/
#define SUPPORT_BY_VALUE

#include "Python.h"
#include "intkeymacros.h"
#include "intvaluemacros.h"

#define INITMODULE PyInit__IIBTree
#include "BTreeModuleTemplate.c"
