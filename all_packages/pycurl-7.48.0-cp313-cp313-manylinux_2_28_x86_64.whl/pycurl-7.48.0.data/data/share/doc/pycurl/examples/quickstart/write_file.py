#! /usr/bin/env python
# vi:ts=4:et

import pycurl

# As long as the file is opened in binary mode, response body
# can be written to it without decoding.
with open('out.html', 'wb') as f:
    c = pycurl.Curl()
    c.setopt(c.URL, 'https://pycurl.github.io/')
    c.setopt(c.WRITEDATA, f)
    c.perform()
    c.close()
