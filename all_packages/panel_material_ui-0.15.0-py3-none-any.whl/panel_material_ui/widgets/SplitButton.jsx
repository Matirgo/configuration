import Button from "@mui/material/Button"
import ButtonGroup from "@mui/material/ButtonGroup"
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown"
import ClickAwayListener from "@mui/material/ClickAwayListener"
import Divider from "@mui/material/Divider"
import MenuItem from "@mui/material/MenuItem"
import {CustomMenu} from "./menu"
import {render_icon, render_icon_text} from "./utils"

const SPLIT_PRIMARY_BUTTON_SX = {
  borderBottomRightRadius: 0,
  borderTopRightRadius: 0
}

const SPLIT_TOGGLE_BUTTON_SX = {
  borderBottomLeftRadius: 0,
  borderTopLeftRadius: 0,
  maxWidth: 50
}

export function render(props, ref) {
  const {data, el, model, view, ...other} = props
  const [active] = model.useState("active")
  const [color] = model.useState("color")
  const [disabled] = model.useState("disabled")
  const [icon] = model.useState("icon")
  const [icon_size] = model.useState("icon_size")
  const [items] = model.useState("items")
  const [label] = model.useState("label")
  const [loading] = model.useState("loading")
  const [mode] = model.useState("mode")
  const [size] = model.useState("size")
  const [variant] = model.useState("variant")
  const [sx] = model.useState("sx")
  const primaryButtonSx = React.useMemo(
    () => (sx ? [SPLIT_PRIMARY_BUTTON_SX, sx] : SPLIT_PRIMARY_BUTTON_SX),
    [sx]
  )

  const [open, setOpen] = React.useState(false)
  const [selectedIndex, setSelectedIndex] = React.useState(active)
  const anchorEl = React.useRef(null)

  const btnRef = React.useRef(null)
  React.useEffect(() => {
    const focus_cb = () => btnRef.current?.focus()
    model.on("msg:custom", focus_cb)
    return () => model.off("msg:custom", focus_cb)
  }, [])

  const handleMenuItemClick = (event, selectedIndex) => {
    setSelectedIndex(selectedIndex)
    setOpen(false)
    model.send_msg({type: "click", item: selectedIndex})
  }

  const handleClose = (event) => {
    if (anchorEl.current && anchorEl.current.contains(event.target)) {
      return
    }
    setOpen(false)
  }

  if (ref == null || (Object.entries(ref).length === 0 && ref.constructor === Object)) {
    ref = undefined
  }

  let current_icon = icon
  let current_label = label
  if (mode === "select") {
    const currentItem = items[active]
    if (currentItem != null) {
      current_label = currentItem.label
      current_icon = currentItem.icon ?? icon
    }
  }

  return (
    <div ref={ref}>
      <ButtonGroup
        color={color}
        disabled={disabled}
        fullWidth
        ref={anchorEl}
        size={size}
        variant={variant}
        {...other}
      >
        <Button
          color={color}
          startIcon={current_icon && render_icon(current_icon, null, size, icon_size)}
          loading={loading}
          onClick={() => model.send_msg({type: "click"})}
          ref={btnRef}
          sx={primaryButtonSx}
          variant={variant}
        >
          {render_icon_text(current_label)}
        </Button>
        <Button
          aria-controls={open ? "split-button-menu" : undefined}
          aria-expanded={open ? "true" : undefined}
          aria-haspopup="menu"
          color={color}
          disabled={disabled || loading}
          onClick={() => setOpen((prevOpen) => !prevOpen)}
          size="small"
          sx={SPLIT_TOGGLE_BUTTON_SX}
          variant={variant}
        >
          <ArrowDropDownIcon />
        </Button>
      </ButtonGroup>
      <CustomMenu
        anchorEl={() => anchorEl.current}
        open={open}
        onClose={() => setOpen(false)}
        view={view}
      >
        {items.map((option, index) => {
          if (option === null || option.label === "---") {
            return <Divider key={`menu-divider-${index}`} />
          }
          const menuItem = (
            <MenuItem
              key={`menu-item-${index}`}
              component={option.href ? "a" : "li"}
              href={option.href}
              selected={mode === "select" && index === selectedIndex}
              onClick={(event) => handleMenuItemClick(event, index)}
              target={option.target}
            >
              {option.icon && render_icon(option.icon, null, null, option.icon_size, null, {pr: "1.5em"})}
              {render_icon_text(option.label)}
            </MenuItem>
          )
          if (option.tooltip) {
            return (
              <Tooltip
                key={`menu-item-tooltip-${index}`}
                title={render_icon_text(option.tooltip)}
                placement="right"
                disableInteractive
              >
                {menuItem}
              </Tooltip>
            )
          }
          return menuItem
        })}
      </CustomMenu>
    </div>
  )
}
