from __future__ import annotations

import typing as t
from functools import partial

import param
from panel.chat.interface import CallbackState
from panel.chat.interface import ChatInterface as PnChatInterface
from panel.layout import Column, Row
from panel.pane.markup import Markdown

from .feed import ChatFeed
from .input import ChatAreaInput

if t.TYPE_CHECKING:
    pass

ICON_MAP = {
    "arrow-back": "undo",
    "trash": "delete",
}


class ChatInterface(ChatFeed, PnChatInterface):
    """
    A chat interface that uses Material UI components.

    :References:

    - https://panel-material-ui.holoviz.org/reference/chat/ChatInterface.html
    - https://panel.holoviz.org/reference/chat/ChatInterface.html

    :Example:

    >>> ChatInterface().servable()
    """

    input_params = param.Dict(
        default={}, doc="""
        Additional parameters to pass to the ChatAreaInput widget.
        Supported keys include any ChatAreaInput param, e.g.
        ``placeholder``, ``enable_upload``, ``max_rows``, ``rows``.
        Updates are applied dynamically after initialization."""
    )

    on_submit = param.Callable(default=None, doc="""
        Callback to invoke when the send button or enter is pressed; should accept an event and instance as args.
        If unspecified, the default behavior is to send a Column containing the input text and views.
        This only affects the user-facing input, and does not affect the `send` method.""")

    widgets = param.Parameter(constant=True, doc="Not supported by panel-material-ui ChatInterface.")

    _input_type = ChatAreaInput

    _rename = {"loading": "loading"}

    def __init__(self, **params):
        self._widget = None
        self._send_watcher = None
        super().__init__(**params)
        # Make the chat log fill available space in the Card's flex layout
        # and scroll when content overflows. Without this, the Feed grows
        # unbounded and pushes the input off-screen.
        # Note: sizing_mode alone doesn't work because _chat_log.height_policy
        # is bound to a reactive expression from _stretches_height(self) that
        # reads the ChatInterface's sizing_mode, not the Feed's. We must use
        # CSS !important to override the flex value that apply_flex computes.
        self._chat_log.stylesheets = [
            *self._chat_log.stylesheets,
            ":host { flex: 1 1 0px !important; min-height: 0 !important; }"
        ]
        # Panel's default auto_scroll_limit (200px) is too small — when
        # streaming replaces message content with taller text, the distance
        # from the bottom can exceed 200px and scroll_to_latest bails out.
        if 'auto_scroll_limit' not in params:
            self.auto_scroll_limit = 2000

    @param.depends("_callback_state", watch=True)
    async def _update_input_disabled(self):
        busy_states = (CallbackState.RUNNING, CallbackState.GENERATING)
        if not self.show_stop or self._callback_state not in busy_states or self._callback_future is None:
            self._widget.loading = False
            self._widget.focus()
        else:
            self._widget.loading = True

    @param.depends("button_properties", watch=True)
    def _init_widgets(self):
        if self._widget is None:
            kw = {k: v for k, v in self.input_params.items() if k not in ("sizing_mode", "disabled")}
            self._widget = ChatAreaInput(sizing_mode="stretch_width", disabled=self.param.disabled, **kw)
            self._widget.on_action("stop", self._click_stop)
            input_container = Row(self._widget, sizing_mode="stretch_width")
            self._input_container.objects = [input_container]
            self._input_layout = input_container
            self._init_button_data()
        else:
            self._widget.param.unwatch(self._send_watcher)
        actions = {}
        for name, data in self._button_data.items():
            if (
                name in ("send", "stop") or (name == "rerun" and not self.show_rerun) or
                (name == "undo" and not self.show_undo) or (name == "clear" and not self.show_clear)
            ):
                continue
            actions[name] = {'icon': ICON_MAP.get(data.icon, data.icon), 'callback': partial(data.callback, self), 'label': name.title()}
        self._widget.actions = actions
        callback = partial(self._button_data["send"].callback, instance=self)
        self._send_watcher = self._widget.param.watch(callback, "value")

    def _click_send(  # type: ignore[override]
        self,
        event: param.parameterized.Event | None = None,
        instance: ChatInterface | None = None
    ) -> None:
        if self.disabled:
            return

        if self.on_submit is not None:
            self.on_submit(event, instance)
            return

        objects = self._widget.views
        if event and event.new:
            objects.append(Markdown(event.new))
        if not objects:
            return
        value = Column(*objects) if len(objects) > 1 else objects[0]
        self.send(value=value, user=self.user, avatar=self.avatar, respond=True)

    _MANAGED_KEYS = frozenset(("sizing_mode", "disabled"))

    @param.depends("input_params", watch=True)
    def _update_input_params(self):
        """Sync input_params to the input widget when changed dynamically."""
        if self._widget is not None:
            for key, value in self.input_params.items():
                if key not in self._MANAGED_KEYS and key in self._widget.param:
                    setattr(self._widget, key, value)

    @param.depends("placeholder_text", "placeholder_params", watch=True, on_init=True)
    def _update_placeholder(self):
        self._placeholder = self._message_type(
            self.placeholder_text,
            avatar='PLACEHOLDER',
            css_classes=["message"],
            **self.placeholder_params
        )

__all__ = ["ChatInterface"]
