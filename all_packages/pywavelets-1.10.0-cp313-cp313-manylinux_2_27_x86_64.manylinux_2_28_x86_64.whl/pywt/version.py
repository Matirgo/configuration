# THIS FILE IS GENERATED DURING THE PYWAVELETS BUILD
# See util/version_utils.py for details

short_version = '1.8.0'
version = '1.8.0'
full_version = '1.8.0'
git_revision = '4bd3a5f'
release = True

if not release:
    version = full_version
