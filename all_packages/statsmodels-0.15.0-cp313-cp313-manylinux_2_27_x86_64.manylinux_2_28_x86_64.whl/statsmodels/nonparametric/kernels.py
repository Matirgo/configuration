"""
Module of kernels that are able to handle continuous as well as categorical
variables (both ordered and unordered)

This is a slight deviation from the current approach in
statsmodels.sandbox.nonparametric.kernels where each kernel is a class
object.

Having kernel functions rather than classes makes extension to a multivariate
kernel density estimation much easier.

NOTE: As it is, this module does not interact with the existing API
"""

import numpy as np
from scipy.special import erf

# TODO:
# - make sure we only receive int input for wang-ryzin and aitchison-aitken
# - Check for the scalar Xi case everywhere


def aitchison_aitken(h, Xi, x, num_levels=None):
    r"""
    The Aitchison-Aitken kernel, used for unordered discrete random variables

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : float or ndarray of int
        The value(s) of the training set; may be a scalar or a 1-D array.
    x : float
        The value at which the kernel density is being estimated.
    num_levels : int, optional
        Gives the user the option to specify the number of levels for the
        random variable. If not given, the number of levels is calculated
        from the data.

    Returns
    -------
    kernel_value : ndarray
        The value of the kernel function at each point in `Xi`.

    Notes
    -----
    See p.18 of [2]_ for details.  The value of the kernel L if :math:`X_{i}=x`
    is :math:`1-\lambda`, otherwise it is :math:`\frac{\lambda}{c-1}`.
    Here :math:`c` is the number of levels plus one of the RV.

    References
    ----------
    .. [*] J. Aitchison and C.G.G. Aitken, "Multivariate binary discrimination
           by the kernel method", Biometrika, vol. 63, pp. 413-420, 1976.
    .. [*] Racine, Jeff. "Nonparametric Econometrics: A Primer," Foundation
           and Trends in Econometrics: Vol 3: No 1, pp1-88., 2008.
    """
    Xi = Xi.reshape(Xi.size)  # seems needed in case Xi is scalar
    if num_levels is None:
        num_levels = np.asarray(np.unique(Xi).size)

    kernel_value = np.ones(Xi.size) * h / (num_levels - 1)
    idx = Xi == x
    kernel_value[idx] = (idx * (1 - h))[idx]
    return kernel_value


def wang_ryzin(h, Xi, x):
    r"""
    The Wang-Ryzin kernel, used for ordered discrete random variables

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : float or ndarray of int
        The value(s) of the training set; may be a scalar or a 1-D array.
    x : float
        The value at which the kernel density is being estimated.

    Returns
    -------
    kernel_value : ndarray
        The value of the kernel function at each point in `Xi`.

    Notes
    -----
    See p. 19 in [1]_ for details.  The value of the kernel L if
    :math:`X_{i}=x` is :math:`1-\lambda`, otherwise it is
    :math:`\frac{1-\lambda}{2}\lambda^{|X_{i}-x|}`, where :math:`\lambda` is
    the bandwidth.

    References
    ----------
    .. [*] Racine, Jeff. "Nonparametric Econometrics: A Primer," Foundation
           and Trends in Econometrics: Vol 3: No 1, pp1-88., 2008.
           http://dx.doi.org/10.1561/0800000009
    .. [*] M.-C. Wang and J. van Ryzin, "A class of smooth estimators for
           discrete distributions", Biometrika, vol. 68, pp. 301-309, 1981.
    """
    Xi = Xi.reshape(Xi.size)  # seems needed in case Xi is scalar
    kernel_value = 0.5 * (1 - h) * (h ** abs(Xi - x))
    idx = Xi == x
    kernel_value[idx] = (idx * (1 - h))[idx]
    return kernel_value


def gaussian(h, Xi, x):
    """
    Gaussian Kernel for continuous variables

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : ndarray
        The value of the training set.
    x : float
        The value at which the kernel density is being estimated.

    Returns
    -------
    kernel_value : ndarray
        The value of the kernel function at each point in `Xi`.
    """
    return (1.0 / np.sqrt(2 * np.pi)) * np.exp(-((Xi - x) ** 2) / (h**2 * 2.0))


def tricube(h, Xi, x):
    """
    Tricube Kernel for continuous variables

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : ndarray
        The value of the training set.
    x : float
        The value at which the kernel density is being estimated.

    Returns
    -------
    kernel_value : ndarray
        The value of the kernel function at each point in `Xi`.
    """
    u = (Xi - x) / h
    u[np.abs(u) > 1] = 0
    return (70.0 / 81) * (1 - np.abs(u) ** 3) ** 3


def gaussian_convolution(h, Xi, x):
    """
    Calculates the Gaussian Convolution Kernel

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : ndarray
        The value of the training set.
    x : float
        The value at which the kernel density is being estimated.

    Returns
    -------
    kernel_value : ndarray
        The value of the kernel function at each point in `Xi`.
    """
    return (1.0 / np.sqrt(4 * np.pi)) * np.exp(-((Xi - x) ** 2) / (h**2 * 4.0))


def wang_ryzin_convolution(h, Xi, Xj):
    """
    Calculates the Wang-Ryzin convolution kernel

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : ndarray of int
        The value of the first training set.
    Xj : float or ndarray of int
        The value of the second training set; may be a scalar or a 1-D
        array.

    Returns
    -------
    ordered : ndarray
        The value of the convolution kernel function for each observation.

    Notes
    -----
    This is the equivalent of the convolution case with the Gaussian kernel.
    However it is not exactly a convolution.
    """
    ordered = np.zeros(Xi.size)
    for x in np.unique(Xi):
        ordered += wang_ryzin(h, Xi, x) * wang_ryzin(h, Xj, x)

    return ordered


def aitchison_aitken_convolution(h, Xi, Xj):
    """
    Calculates the Aitchison-Aitken convolution kernel

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : ndarray of int
        The value of the first training set.
    Xj : float or ndarray of int
        The value of the second training set; may be a scalar or a 1-D
        array.

    Returns
    -------
    ordered : ndarray
        The value of the convolution kernel function for each observation.
    """
    Xi_vals = np.unique(Xi)
    ordered = np.zeros(Xi.size)
    num_levels = Xi_vals.size
    for x in Xi_vals:
        ordered += aitchison_aitken(h, Xi, x, num_levels=num_levels) * aitchison_aitken(
            h, Xj, x, num_levels=num_levels
        )

    return ordered


def gaussian_cdf(h, Xi, x):
    """
    Calculates the Gaussian cumulative distribution function

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : ndarray
        The value of the training set.
    x : float
        The value at which the kernel cdf is being estimated.

    Returns
    -------
    ndarray
        The value of the kernel cdf at each training point.
    """
    return 0.5 * h * (1 + erf((x - Xi) / (h * np.sqrt(2))))


def aitchison_aitken_cdf(h, Xi, x_u):
    """
    Calculates the Aitchison-Aitken cumulative distribution function

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : ndarray of int
        The value of the training set.
    x_u : int
        The value at which the kernel cdf is being estimated.

    Returns
    -------
    ordered : ndarray
        The value of the kernel cdf for each observation.
    """
    x_u = int(x_u)
    Xi_vals = np.unique(Xi)
    ordered = np.zeros(Xi.size)
    num_levels = Xi_vals.size
    for x in Xi_vals:
        if x <= x_u:  # FIXME: why a comparison for unordered variables?
            ordered += aitchison_aitken(h, Xi, x, num_levels=num_levels)

    return ordered


def wang_ryzin_cdf(h, Xi, x_u):
    """
    Calculates the Wang-Ryzin cumulative distribution function

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : ndarray of int
        The value of the training set.
    x_u : scalar
        The value at which the kernel cdf is being estimated.

    Returns
    -------
    ordered : ndarray
        The value of the kernel cdf for each observation.
    """
    ordered = np.zeros(Xi.size)
    for x in np.unique(Xi):
        if x <= x_u:
            ordered += wang_ryzin(h, Xi, x)

    return ordered


def d_gaussian(h, Xi, x):
    """
    Calculates the derivative of the Gaussian kernel

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : ndarray
        The value of the training set.
    x : float
        The value at which the kernel density is being estimated.

    Returns
    -------
    ndarray
        The value of the derivative of the Gaussian kernel at each
        training point.
    """
    return 2 * (Xi - x) * gaussian(h, Xi, x) / h**2


def aitchison_aitken_reg(h, Xi, x):
    """
    A version for the Aitchison-Aitken kernel for nonparametric regression

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : ndarray of int
        The value of the training set.
    x : float
        The value at which the kernel density is being estimated.

    Returns
    -------
    kernel_value : ndarray
        The value of the kernel function at each point in `Xi`.

    Notes
    -----
    Suggested by Li and Racine.
    """
    kernel_value = np.ones(Xi.size)
    ix = Xi != x
    inDom = ix * h
    kernel_value[ix] = inDom[ix]
    return kernel_value


def wang_ryzin_reg(h, Xi, x):
    """
    A version for the Wang-Ryzin kernel for nonparametric regression

    Parameters
    ----------
    h : float
        The bandwidth used to estimate the value of the kernel function.
    Xi : ndarray of int
        The value of the training set.
    x : float
        The value at which the kernel density is being estimated.

    Returns
    -------
    kernel_value : ndarray
        The value of the kernel function at each point in `Xi`.

    Notes
    -----
    Suggested by Li and Racine, Ch.4.

    References
    ----------
    .. [*] Racine, Jeff. "Nonparametric Econometrics: A Primer," Foundation
           and Trends in Econometrics: Vol 3: No 1, pp1-88., 2008.
           http://dx.doi.org/10.1561/0800000009
    """
    return h ** abs(Xi - x)
