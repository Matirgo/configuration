import traceback
from datetime import datetime, timezone
from typing import List, Optional

# 패키지 실행과 직접 실행을 모두 지원하기 위한 import 처리
from s2n.s2nscanner.interfaces import (
    Finding,
    PluginConfig,
    PluginContext,
    PluginError,
    PluginResult,
    PluginStatus,
)
from s2n.s2nscanner.plugins.csrf.csrf_scan import csrf_scan
from s2n.s2nscanner.logger import get_logger


# 전용 로거
logger = get_logger("plugins.csrf")


# ======= CSRF 스캐너 기능 개발부 =========

# 메인 플러그인 스캐너 클래스 정의입니다.
class CSRFScanner:
    """CSRF 취약점 스캐너"""
    name = "csrf"
    description = "CSRF scanner plugin from s2n.s2nscanner"

    #  CSRF Plugin의 설정 파라미터입니다.
    def __init__(self, config: Optional[PluginConfig] = None):
        self.config = config or {}

    # CSRFScanner.run(플러그인_컨텍스트)로 플러그인을 실행합니다.
    def run(self, plugin_context: PluginContext) -> PluginResult:
        start_time = datetime.now(timezone.utc)
        findings: List[Finding] = []
        # 나중에 타입 확인 
        client = plugin_context.scan_context.http_client
        # 이 url 목록을 차례대로 or 병렬로 scan() 함수에 적용한다.
        target_urls = plugin_context.target_urls

        try:
            # for 문이든 뭐든 써서,  target_urls로 개별 url 스캔 수행하게 만들기

            total_urls = len(target_urls)
            for idx, url in enumerate(target_urls, 1):
                # Progress logging
                if plugin_context.logger:
                    plugin_context.logger.info(f"[*] Scanning URL {idx}/{total_urls}: {url}")
                else:
                    logger.info(f"[*] Scanning URL {idx}/{total_urls}: {url}")

                scan_result = csrf_scan(url, http_client=client, plugin_context=plugin_context)
                findings.extend(scan_result)

            end_time = datetime.now(timezone.utc)
            return PluginResult(
                plugin_name=self.name,
                status=PluginStatus.PARTIAL if findings else PluginStatus.SUCCESS,
                findings=findings,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=(end_time - start_time).total_seconds(),
                urls_scanned=total_urls,
                requests_sent=total_urls * 6  # 2 (L2) + 2 (L4/L8) + 2 (L7)
            )

        except Exception as e:
            logger.exception("[CSRFScanner.run] plugin error: %s", e)
            end_time = datetime.now(timezone.utc)
            return PluginResult(
                plugin_name=self.name,
                status=PluginStatus.FAILED,
                findings=findings,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=(end_time - start_time).total_seconds(),
                error=PluginError(
                    error_type=type(e).__name__,
                    message=str(e),
                    traceback=traceback.format_exc()
                )
            )


# 메인 함수
def main(config: Optional[PluginConfig] = None):
    return CSRFScanner(config)


# 이 파일을 직접 실행할 때 main()을 호출
if __name__ == "__main__":
    main()
