##############################################################################
#
# Copyright (c) 2001, 2002 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#
##############################################################################
"""Test a gettext implementation of a Message Catalog.
"""
import os

from zope.i18n.gettextmessagecatalog import GettextMessageCatalog
from zope.i18n.testing import compile_po
from zope.i18n.tests import test_imessagecatalog


class GettextMessageCatalogTest(test_imessagecatalog.TestIMessageCatalog):

    def _getMessageCatalog(self):
        from zope.i18n import tests
        path = os.path.dirname(tests.__file__)
        self._path = os.path.join(
            path, 'locale-default', 'en', 'LC_MESSAGES', 'default.mo')
        compile_po(self._path)
        catalog = GettextMessageCatalog('en', 'default', self._path)
        return catalog

    def _getUniqueIndentifier(self):
        return self._path
