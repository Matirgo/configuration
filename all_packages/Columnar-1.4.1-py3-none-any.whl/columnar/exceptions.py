class TableOverflowError(Exception):
    pass