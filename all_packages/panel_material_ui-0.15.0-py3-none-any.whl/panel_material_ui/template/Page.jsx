import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Divider from "@mui/material/Divider";
import Drawer from "@mui/material/Drawer";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import LinearProgress from "@mui/material/LinearProgress";
import MenuIcon from "@mui/icons-material/Menu";
import MenuOpenIcon from "@mui/icons-material/MenuOpen";
import DarkMode from "@mui/icons-material/DarkMode";
import LightMode from "@mui/icons-material/LightMode";
import TocIcon from "@mui/icons-material/Toc";
import Tooltip from "@mui/material/Tooltip";
import useMediaQuery from "@mui/material/useMediaQuery";
import {styled, useTheme} from "@mui/material/styles";
import {apply_flex, dark_mode, setup_global_styles, render_icon_text} from "./utils"

const PAGE_ROOT_SX = {display: "flex", width: "100vw", height: "100vh", overflow: "hidden"}
const PAGE_APPBAR_SX = {zIndex: (theme) => theme.zIndex.drawer + 1}
const PAGE_BUSY_TOOLBAR_SX = {m: "4px"}
const PAGE_HEADER_ICON_SX = {
  mr: 2,
  animation: "var(--pmui-header-menu-animation, none)",
  "@keyframes pulse": {
    "0%": {transform: "scale(1)"},
    "50%": {transform: "scale(1.25)"},
    "100%": {transform: "scale(1)"}
  }
}
const PAGE_DRAWER_RESIZE_HANDLE_SX = {
  position: "absolute",
  top: 0,
  right: 0,
  width: "4px",
  height: "100%",
  cursor: "col-resize",
  backgroundColor: "transparent",
  zIndex: 1000,
  "&:hover": {
    borderRightWidth: "2px",
  },
  "&:before": {
    content: '""',
    position: "absolute",
    top: 0,
    right: "-3px",
    width: "6px",
    height: "100%",
    backgroundColor: "transparent"
  }
}

// Normalize a width value into an MUI sx `maxWidth`.
// Accepts a number (interpreted as pixels), a CSS length string
// (e.g. "70ch", "60rem", "90%"), or a breakpoint dict
// (e.g. {xs: "100%", md: 720, lg: 960}) which maps to a responsive sx object
// where each value applies at that breakpoint and up. Returns undefined when unset.
const to_css_width = (v) => (typeof v === "number" ? `${v}px` : v)
const to_max_width = (v) => {
  if (v == null) { return undefined }
  if (typeof v === "object") {
    return Object.fromEntries(
      Object.entries(v).map(([bp, w]) => [bp, to_css_width(w)])
    )
  }
  return to_css_width(v)
}

const Main = styled("main", {shouldForwardProp: (prop) => !["open", "variant", "sidebar_width", "contextbar_open", "context_variant", "contextbar_width"].includes(prop)})(
  ({sidebar_width, contextbar_width, theme, open, variant, contextbar_open, context_variant}) => {
    return ({
      backgroundColor: theme.palette.background.paper,
      flexGrow: 1,
      marginLeft: variant === "persistent" ? `-${sidebar_width}px` : "0px",
      marginRight: context_variant === "persistent" ? `-${contextbar_width}px` : "0px",
      padding: "0px",
      maxWidth: "100%",
      p: 3,
      transition: theme.transitions.create("margin", {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      height: "auto",
      overflow: "hidden",
      width: {sm: `calc(100% - ${sidebar_width}px)`},
      variants: [
        {
          props: ({open, variant}) => open && variant === "persistent",
          style: {
            transition: theme.transitions.create("margin", {
              easing: theme.transitions.easing.easeOut,
              duration: theme.transitions.duration.enteringScreen,
            }),
            marginLeft: 0,
          },
        },
        {
          props: ({contextbar_open, context_variant}) => contextbar_open && context_variant === "persistent",
          style: {
            transition: theme.transitions.create("margin", {
              easing: theme.transitions.easing.easeOut,
              duration: theme.transitions.duration.enteringScreen,
            }),
            marginRight: 0,
          },
        },
      ],
    })
  }
)

export function render({model, view}) {
  const theme = useTheme()
  const [busy] = model.useState("busy")
  const [busy_indicator] = model.useState("busy_indicator")
  const [contextbar_open, contextOpen] = model.useState("contextbar_open")
  const [contextbar_resizable] = model.useState("contextbar_resizable")
  const [contextbar_variant] = model.useState("contextbar_variant")
  const [contextbar_width, setContextbarWidth] = model.useState("contextbar_width")
  const [main_width] = model.useState("main_width")
  const [app_bar_width] = model.useState("app_bar_width")
  const [dark_theme, setDarkTheme] = model.useState("dark_theme")
  const [logo] = model.useState("logo")
  const [open, setOpen] = model.useState("sidebar_open")
  const [sidebar_resizable] = model.useState("sidebar_resizable")
  const [sidebar_width, setSidebarWidth] = model.useState("sidebar_width")
  const [theme_toggle] = model.useState("theme_toggle")

  // Draggable sidebar state
  const [isDragging, setIsDragging] = React.useState(false)
  const [dragStartX, setDragStartX] = React.useState(0)
  const [dragStartWidth, setDragStartWidth] = React.useState(0)

  // Draggable contextbar state
  const [isContextDragging, setIsContextDragging] = React.useState(false)
  const [contextDragStartX, setContextDragStartX] = React.useState(0)
  const [contextDragStartWidth, setContextDragStartWidth] = React.useState(0)
  const [site_url] = model.useState("site_url")
  const [title] = model.useState("title")
  const [variant] = model.useState("sidebar_variant")
  const [sx] = model.useState("sx")
  const sidebar = model.get_child("sidebar")
  const contextbar = model.get_child("contextbar")
  const header = model.get_child("header")
  const main = model.get_child("main")
  const isXl = useMediaQuery(theme.breakpoints.up("xl"))
  const isLg = useMediaQuery(theme.breakpoints.up("lg"))
  const isMd = useMediaQuery(theme.breakpoints.up("md"))
  const isSm = useMediaQuery(theme.breakpoints.up("sm"))
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"))

  const drawer_variant = variant === "auto" ? (isMobile ? "temporary": "persistent") : variant
  const context_drawer_variant = contextbar_variant === "auto" ? (isMobile ? "temporary" : "persistent") : contextbar_variant

  const toolbarSx = busy_indicator === "linear" ? PAGE_BUSY_TOOLBAR_SX : undefined
  const pageRootSx = React.useMemo(() => (sx ? [PAGE_ROOT_SX, sx] : PAGE_ROOT_SX), [sx])
  const drawerSx = React.useMemo(() => ({
    display: "flex",
    flexDirection: "column",
    flexShrink: 0,
    height: "100vh",
    "& .MuiDrawer-paper": {
      width: sidebar_width,
      height: "100vh",
      boxSizing: "border-box",
      position: "relative",
      overflowX: "hidden"
    },
  }), [sidebar_width])
  const contextDrawerSx = React.useMemo(() => ({
    display: "flex",
    flexDirection: "column",
    flexShrink: 0,
    height: "100vh",
    ...(context_drawer_variant !== "temporary" && {width: contextbar_width}),
    zIndex: (theme) => theme.zIndex.drawer + 2,
    "& .MuiDrawer-paper": {
      width: contextbar_width,
      height: "100vh",
      boxSizing: "border-box",
      ...(context_drawer_variant !== "temporary" && {position: "relative"}),
      overflowX: "hidden"
    },
  }), [contextbar_width, context_drawer_variant])

  const logoContent = React.useMemo(() => {
    if (!logo) { return null }
    if (typeof logo === "string") { return logo }

    let resolved = logo
    if (isXl && resolved.xl) {
      resolved = resolved.xl
    } else if (isLg && resolved.lg) {
      resolved = resolved.lg
    } else if (isMd && resolved.md) {
      resolved = resolved.md
    } else if (isSm && resolved.sm) {
      resolved = resolved.sm
    } else if (resolved.xs) {
      resolved = resolved.xs
    }

    if (dark_theme && resolved.dark) { return resolved.dark }
    if (!dark_theme && resolved.light) { return resolved.light }
    if (typeof resolved === "string") { return resolved }

    return logo.default || Object.values(logo)[0];
  }, [logo, theme.breakpoints, isXl, isLg, isMd, isSm, dark_theme])

  React.useEffect(() => {
    const handler = () => {
      sidebar.map((object, index) => {
        apply_flex(view.get_child_view(model.sidebar[index]), "column")
      })
      contextbar.map((object, index) => {
        apply_flex(view.get_child_view(model.contextbar[index]), "column")
      })
      header.map((object, index) => {
        apply_flex(view.get_child_view(model.header[index]), "row")
      })
      main.map((object, index) => {
        apply_flex(view.get_child_view(model.main[index]), "column")
      })
    }
    model.on("lifecycle:update_layout", handler)
    return () => model.off?.("lifecycle:update_layout", handler)
  }, [])

  // Set up debouncing of busy indicator
  const [idle, setIdle] = React.useState(true);
  const timerRef = React.useRef(undefined)
  React.useEffect(() => {
    if (busy) {
      timerRef.current = setTimeout(() => {
        setIdle(false)
      }, 1000)
    } else {
      setIdle(true)
      clearTimeout(timerRef.current)
    }
  }, [busy])
  React.useEffect(() => () => clearTimeout(timerRef.current), [])

  const toggleTheme = () => {
    setDarkTheme(!dark_theme)
  }

  setup_global_styles(view, theme, view.model.data._custom_theme)
  React.useEffect(() => dark_mode.set_value(dark_theme), [dark_theme])

  const [highlight, setHighlight] = React.useState(false)

  const triggerHighlight = () => {
    setHighlight(true)
    setTimeout(() => setHighlight(false), 300)
  }

  const handleDragEnd = React.useCallback(() => {
    setIsDragging(false)
    setDragStartX(null)
    setDragStartWidth(null)
    document.body.style.cursor = ""
  }, [])

  // Drag handlers for sidebar resizing
  const handleDragStart = React.useCallback((e) => {
    const clientX = e.type.startsWith("touch") ? e.touches[0].clientX : e.clientX
    setIsDragging(true)
    setDragStartX(clientX)
    setDragStartWidth(sidebar_width)
    e.preventDefault()
  }, [sidebar_width])

  const handleDragMove = React.useCallback((e) => {
    if (!isDragging) { return }

    const clientX = e.type.startsWith("touch") ? e.touches[0].clientX : e.clientX
    const deltaX = clientX - dragStartX
    const newWidth = dragStartWidth + deltaX

    // If width gets close to 0, collapse the sidebar completely
    if (newWidth < 50) {
      setOpen(false)
      triggerHighlight()
      handleDragEnd()
    } else {
      // Update width immediately for responsive feedback
      setSidebarWidth(Math.round(newWidth))
    }
    e.preventDefault()
  }, [isDragging, dragStartX, dragStartWidth, setOpen, triggerHighlight, handleDragEnd])

  // Contextbar drag handlers
  const handleContextDragEnd = React.useCallback(() => {
    setIsContextDragging(false)
    setContextDragStartX(null)
    setContextDragStartWidth(null)
    document.body.style.cursor = ""
  }, [])

  const handleContextDragStart = React.useCallback((e) => {
    const clientX = e.type.startsWith("touch") ? e.touches[0].clientX : e.clientX
    setIsContextDragging(true)
    setContextDragStartX(clientX)
    setContextDragStartWidth(contextbar_width)
    e.preventDefault()
  }, [contextbar_width])

  const handleContextDragMove = React.useCallback((e) => {
    if (!isContextDragging) { return }

    const clientX = e.type.startsWith("touch") ? e.touches[0].clientX : e.clientX
    const deltaX = contextDragStartX - clientX
    const newWidth = contextDragStartWidth + deltaX

    if (newWidth < 50) {
      contextOpen(false)
      handleContextDragEnd()
    } else {
      setContextbarWidth(Math.round(newWidth))
    }
    e.preventDefault()
  }, [isContextDragging, contextDragStartX, contextDragStartWidth, contextOpen, handleContextDragEnd])

  // Add global mouse/touch event listeners when dragging contextbar
  React.useEffect(() => {
    if (isContextDragging) {
      const handleMouseMove = (e) => handleContextDragMove(e)
      const handleMouseUp = () => handleContextDragEnd()
      const handleTouchMove = (e) => handleContextDragMove(e)
      const handleTouchEnd = () => handleContextDragEnd()

      document.addEventListener("mousemove", handleMouseMove)
      document.addEventListener("mouseup", handleMouseUp)
      document.addEventListener("touchmove", handleTouchMove, {passive: false})
      document.addEventListener("touchend", handleTouchEnd)

      return () => {
        document.removeEventListener("mousemove", handleMouseMove)
        document.removeEventListener("mouseup", handleMouseUp)
        document.removeEventListener("touchmove", handleTouchMove)
        document.removeEventListener("touchend", handleTouchEnd)
      }
    }
  }, [isContextDragging, handleContextDragMove, handleContextDragEnd])

  // Add global mouse/touch event listeners when dragging
  React.useEffect(() => {
    if (isDragging) {
      const handleMouseMove = (e) => handleDragMove(e)
      const handleMouseUp = () => handleDragEnd()
      const handleTouchMove = (e) => handleDragMove(e)
      const handleTouchEnd = () => handleDragEnd()

      document.addEventListener("mousemove", handleMouseMove)
      document.addEventListener("mouseup", handleMouseUp)
      document.addEventListener("touchmove", handleTouchMove, {passive: false})
      document.addEventListener("touchend", handleTouchEnd)

      return () => {
        document.removeEventListener("mousemove", handleMouseMove)
        document.removeEventListener("mouseup", handleMouseUp)
        document.removeEventListener("touchmove", handleTouchMove)
        document.removeEventListener("touchend", handleTouchEnd)
      }
    }
  }, [isDragging, handleDragMove, handleDragEnd])

  const drawer = sidebar.length > 0 ? (
    <Drawer
      slotProps={{paper: {className: "sidebar"}}}
      anchor="left"
      open={open}
      onClose={drawer_variant === "temporary" ? (() => setOpen(false)) : null}
      sx={drawerSx}
      variant={drawer_variant}
    >
      <Toolbar sx={toolbarSx}>
        <Typography variant="h5">&nbsp;</Typography>
      </Toolbar>
      <Box sx={{flexGrow: 1, display: "flex", flexDirection: "column"}}>
        {sidebar.map((object, index) => {
          apply_flex(view.get_child_view(model.sidebar[index]), "column")
          return object
        })}
      </Box>
      {sidebar_resizable && (
        <Box
          onMouseDown={handleDragStart}
          onTouchStart={handleDragStart}
          sx={[PAGE_DRAWER_RESIZE_HANDLE_SX, {
            borderRight: `1px solid ${theme.palette.divider}`,
            "&:hover": {borderRightColor: theme.palette.divider, borderRightWidth: "2px"}
          }]}
          aria-label="Resize sidebar"
          title="Drag to resize sidebar"
        />
      )}
    </Drawer>
  ) : null

  const context_drawer = contextbar.length > 0 ? (
    <Drawer
      slotProps={{paper: {className: "contextbar"}}}
      anchor="right"
      open={contextbar_open}
      onClose={context_drawer_variant === "temporary" ? (() => contextOpen(false)) : null}
      sx={contextDrawerSx}
      variant={context_drawer_variant}
    >
      {context_drawer_variant !== "temporary" && (
        <Toolbar sx={toolbarSx}>
          <Typography variant="h5">&nbsp;</Typography>
        </Toolbar>
      )}
      {contextbar_resizable && (
        <Box
          onMouseDown={handleContextDragStart}
          onTouchStart={handleContextDragStart}
          sx={[PAGE_DRAWER_RESIZE_HANDLE_SX, {
            right: "auto",
            left: 0,
            borderLeft: `1px solid ${theme.palette.divider}`,
            borderRight: "none",
            "&:hover": {borderLeftColor: theme.palette.divider, borderLeftWidth: "2px"},
            "&:before": {right: "auto", left: "-3px"}
          }]}
          aria-label="Resize contextbar"
          title="Drag to resize contextbar"
        />
      )}
      {contextbar.map((object, index) => {
        apply_flex(view.get_child_view(model.contextbar[index]), "column")
        return object
      })}
    </Drawer>
  ) : null

  const color_scheme = dark_theme ? "dark" : "light"
  const main_stretch = model.main.length === 1 && (model.main[0].sizing_mode && (model.main[0].sizing_mode.includes("height") ||  model.main[0].sizing_mode.includes("both")))
  const primary_color = model.theme_config?.palette?.primary?.main ?? model.theme_config?.[color_scheme]?.palette?.primary?.main
  const header_sx = React.useMemo(
    () => (primary_color == null ? {backgroundColor: "#0072b5", color: "#ffffff"} : {}),
    [primary_color]
  )
  const appBarSx = React.useMemo(() => [PAGE_APPBAR_SX, header_sx], [header_sx])
  const appBarToolbarSx = React.useMemo(() => {
    // app_bar_width follows main_width when unset, so the header stays aligned
    // with the clamped main content; an explicit app_bar_width overrides it.
    const maxWidth = to_max_width(app_bar_width ?? main_width)
    return maxWidth == null ? undefined : {maxWidth, width: "100%", alignSelf: "center"}
  }, [app_bar_width, main_width])
  const mainContentSx = React.useMemo(() => {
    const maxWidth = to_max_width(main_width)
    return {
      flexGrow: 1,
      display: "flex",
      minHeight: 0,
      flexDirection: "column",
      overflowY: main_stretch ? "hidden" : "auto",
      // alignSelf centers the clamped content within the (column) flex parent;
      // margin:auto would compute to resolved pixels and is harder to assert on.
      ...(maxWidth == null ? {} : {maxWidth, width: "100%", alignSelf: "center"}),
    }
  }, [main_stretch, main_width])

  return (
    <Box className={`mui-${color_scheme}`} sx={pageRootSx}>
      <AppBar position="fixed" color="primary" className="header" sx={appBarSx}>
        <Toolbar sx={appBarToolbarSx}>
          {(model.sidebar.length > 0 && drawer_variant !== "permanent") &&
            <Tooltip enterDelay={500} title={open ? "Close drawer" : "Open drawer"}>
              <IconButton
                color="inherit"
                aria-label={open ? "Close drawer" : "Open drawer"}
                onClick={() => setOpen(!open)}
                edge="start"
                sx={PAGE_HEADER_ICON_SX}
                style={{"--pmui-header-menu-animation": highlight ? "pulse 300ms ease-out" : "none"}}
              >
                {open ? <MenuOpenIcon/> : <MenuIcon />}
              </IconButton>
            </Tooltip>
          }
          {(logo || title) && (
            <Box sx={{display: "flex", alignItems: "center", gap: 2}}>
              {logo && (
                <a href={site_url} style={{display: "flex", alignItems: "center"}}>
                  <img
                    src={logoContent}
                    alt="Logo"
                    className="logo"
                    style={{height: "2.5em", display: "block"}}
                  />
                </a>
              )}
              {title && (
                <a href={site_url} style={{textDecoration: "none", display: "flex", alignItems: "center"}}>
                  <Typography variant="h3" className="title" sx={{color: "white", lineHeight: 1}}>
                    {render_icon_text(title)}
                  </Typography>
                </a>
              )}
            </Box>
          )}
          <Box sx={{alignItems: "center", flexGrow: 1, display: "flex", flexDirection: "row"}}>
            {header.map((object, index) => {
              apply_flex(view.get_child_view(model.header[index]), "row")
              return object
            })}
          </Box>
          {theme_toggle &&
            <Tooltip enterDelay={500} title="Toggle theme">
              <IconButton onClick={toggleTheme} aria-label="Toggle theme" color="inherit" align="right">
                {dark_theme ? <DarkMode /> : <LightMode />}
              </IconButton>
            </Tooltip>
          }
          {(model.contextbar.length > 0 && context_drawer_variant !== "permanent") &&
            <Tooltip enterDelay={500} title={contextbar_open ? "Close contextbar" : "Open contextbar"}>
              <IconButton
                color="inherit"
                aria-label={contextbar_open ? "Close contextbar" : "Open contextbar"}
                onClick={() => contextOpen(!contextbar_open)}
                edge="end"
              >
                <TocIcon />
              </IconButton>
            </Tooltip>
          }
          {busy_indicator === "circular" &&
            <CircularProgress
              disableShrink
              size="1.4em"
              sx={{color: "white"}}
              thickness={5}
              variant={idle ? "determinate" : "indeterminate"}
              value={idle ? 100 : 0}
            />}
        </Toolbar>
        {busy_indicator === "linear" &&
          <LinearProgress
            sx={{
              width: "100%",
              opacity: idle ? 0 : 1,
              transition: theme.transitions.create("opacity", {
                duration: theme.transitions.duration.short,
              })
            }}
            variant={idle ? "determinate" : "indeterminate"}
            color="primary"
            value={idle ? 100 : 0}
          />
        }
      </AppBar>
      {drawer &&
      <Box
        component="nav"
        sx={
          drawer_variant === "temporary" ? (
            {width: 0, flexShrink: {xs: 0}}
          ) : (
            {width: {sm: sidebar_width}, flexShrink: {sm: 0}}
          )
        }
      >
        {drawer}
      </Box>}
      <Main className="main" open={open} sidebar_width={sidebar_width} variant={drawer_variant} contextbar_open={contextbar_open} contextbar_width={contextbar_width} context_variant={context_drawer_variant}>
        <Box sx={{display: "flex", flexDirection: "column", height: "100%"}}>
          <Toolbar sx={toolbarSx}>
            <Typography variant="h5">&nbsp;</Typography>
          </Toolbar>
          <Box className="main-content" sx={mainContentSx}>
            {main.map((object, index) => {
              apply_flex(view.get_child_view(model.main[index]), "column")
              return object
            })}
          </Box>
        </Box>
      </Main>
      {context_drawer &&
      <Box
        component="nav"
        sx={
          context_drawer_variant === "temporary" ? (
            {width: 0, flexShrink: {xs: 0}}
          ) : (
            {width: {sm: contextbar_width}, flexShrink: {sm: 0}}
          )
        }
      >
        {context_drawer}
      </Box>}
    </Box>
  );
}
