All of the people who have made at least one contribution to conda-index.
Authors are sorted alphabetically.

* Andrew Vallette
* Carl Anderson
* Conda Bot
* Dan Yeaw
* Daniel Holth
* Jannis Leidel
* Jay Roebuck
* Ken Odegard
* Klaus Zimmermann
* Pavel Zwerschke
* Ryan Keith
* Sophia Castellarin
* conda-bot
* dependabot[bot]
* jaimergp
* pre-commit-ci[bot]
