import sys

from OpenSSL import __version__ as PYOPENSSL_VERSION_STRING
from packaging.version import Version
from parsel import __version__ as PARSEL_VERSION_STRING
from twisted import version as TWISTED_VERSION
from twisted.python.versions import Version as TxVersion

# improved urllib.robotparser, https://github.com/python/cpython/pull/149374
STDLIB_IMPROVED_ROBOTFILEPARSER = sys.version_info >= (3, 14, 5) or (
    (3, 13, 14) <= sys.version_info < (3, 14)
)

TWISTED_FAILURE_HAS_STACK = TWISTED_VERSION < TxVersion("twisted", 24, 10, 0)
# changes to private _sslverify code, https://github.com/twisted/twisted/pull/12506
TWISTED_TLS_NEW_IMPL = TWISTED_VERSION >= TxVersion("twisted", 26, 4, 0)
# lowerMaximumSecurityTo off-by-1, https://github.com/twisted/twisted/issues/10232
TWISTED_TLS_LIMITS_OFFBY1 = TWISTED_VERSION < TxVersion("twisted", 26, 4, 0)

PARSEL_VERSION = Version(PARSEL_VERSION_STRING)
# Selector.jmespath() support
PARSEL_SUPPORTS_JMESPATH = PARSEL_VERSION >= Version("1.8.0")

PYOPENSSL_VERSION = Version(PYOPENSSL_VERSION_STRING)
# SSL.Context.set_cipher_list() creates a temporary connection, making the context immutable
PYOPENSSL_SET_CIPHER_LIST_TMP_CONN = PYOPENSSL_VERSION < Version("25.2.0")
