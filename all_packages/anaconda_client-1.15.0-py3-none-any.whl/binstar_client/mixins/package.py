from binstar_client.errors import Conflict


class PackageMixin:
    def copy(
        self,
        owner,
        package,
        version,
        basename=None,
        to_owner=None,
        from_label='main',
        to_label='main',
        replace=False,
        update=False,
    ):
        copy_path = '/'.join((owner, package, version, basename or ''))
        url = '{}/copy/package/{}'.format(self.domain, copy_path)

        payload = {'to_owner': to_owner, 'from_channel': from_label, 'to_channel': to_label}

        if replace:
            res = self.session.put(url, json=payload)
        elif update:
            res = self.session.patch(url, json=payload)
        else:
            res = self.session.post(url, json=payload)

        try:
            self._check_response(res)
        except Conflict as conflict:
            raise Conflict(
                'File conflict while copying! Try to use --replace or --update options for force copying'
            ) from conflict

        return res.json()
