"""
Code for cusp neighborhoods.
"""
